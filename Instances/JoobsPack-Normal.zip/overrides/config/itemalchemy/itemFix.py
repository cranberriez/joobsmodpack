import json

# Define the array of keys to delete
keys_to_delete = [
    'modern_industrialization', 
    'ae2', 
    'ae2wtlib',
    'spectrum',
    'ad_astra',
    'mysticalagriculture',
    'spectrum'
    ]

# Load the data from the file
with open('emc_config.json', 'r') as f:
    data = json.load(f)

# Go through each item and check if it is in the keys_to_delete list
for key in list(data.keys()):  # We use list to create a copy of keys for safe iteration while modifying dictionary
    if key in keys_to_delete:
        del data[key]  # or del data[key] if you want to remove it

# Save the updated data back to the file
with open('data.json', 'w') as f:
    json.dump(data, f, indent=2)  # Use indent to format the output nicely
